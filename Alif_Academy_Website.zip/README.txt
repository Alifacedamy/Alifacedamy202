ALIF ACADEMY WEBSITE
====================

Files:
- index.html  = website pages/content
- style.css   = design/layout

To view:
1. Open index.html in a web browser.
2. To edit text, open index.html in a text/code editor.
3. Replace the teacher and gallery placeholders with your real information/photos.

The website is responsive and works on phones.

Contact currently configured:
oromiakoo2026@gmail.com

Location:
Oromia, Ethiopia

Suggested domain:
alifacademy.com
